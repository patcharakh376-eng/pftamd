# Prehistoric Fauna Taming Addon (Forge 1.16.5)

## วิธี build
1. ติดตั้ง **JDK 8** (ForgeGradle 4 ต้องใช้ Java 8)
2. ดาวน์โหลด **Forge MDK 1.16.5** (files.minecraftforge.net) แล้วคัดลอก `gradlew`, `gradlew.bat` และโฟลเดอร์ `gradle/` ใส่ในโฟลเดอร์นี้
3. เปิด terminal ในโฟลเดอร์นี้ แล้วรัน `gradlew build`
4. ไฟล์ผลลัพธ์อยู่ที่ `build/libs/pftame-1.16.5-1.0.0.jar` เอาไปใส่โฟลเดอร์ `mods` พร้อม Prehistoric Fauna 2.2.5

## วิธีเล่น
- **T-Rex ป่า:** คลิกขวาด้วยเนื้อทุกชนิด (เนื้อ, ปลา, rotten flesh ฯลฯ) มีโอกาส 33% ต่อชิ้น (แก้ได้ใน config)
- **สั่งโหมด:** คลิกขวาไดโนที่เลี้ยงแล้วด้วย **ไม้ (stick)** วนโหมด Wander -> Follow -> Sit (เปลี่ยนไอเทมได้ใน config `commandItem`)
- **Triceratops:** ใช้ระบบเลี้ยง/ขี่แบบม้าของ mod เดิม พอเลี้ยงสำเร็จแล้วใช้ไม้สั่งโหมดได้เหมือน T-Rex
- T-Rex ที่เลี้ยงแล้วให้เนื้อเพื่อฟื้นเลือดได้ และจะไม่โจมตีเจ้าของ
- Config อยู่ที่ `config/pftame-common.toml`

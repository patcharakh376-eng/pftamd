package com.pftame;

import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.passive.horse.AbstractHorseEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

public final class PetHelper {
    public static final String MODE_KEY = "pftame_mode";
    public static final int WANDER = 0;
    public static final int FOLLOW = 1;
    public static final int SIT = 2;

    private static EntityType<?> trexType;
    private static EntityType<?> triType;

    private PetHelper() {}

    private static EntityType<?> lookup(String path) {
        ResourceLocation id = new ResourceLocation("prehistoricfauna", path);
        return ForgeRegistries.ENTITIES.containsKey(id) ? ForgeRegistries.ENTITIES.getValue(id) : null;
    }

    public static boolean isTrex(Entity e) {
        if (trexType == null) trexType = lookup("tyrannosaurus");
        return trexType != null && e.getType() == trexType;
    }

    public static boolean isTriceratops(Entity e) {
        if (triType == null) triType = lookup("triceratops");
        return triType != null && e.getType() == triType;
    }

    public static boolean isManaged(Entity e) {
        return e instanceof MobEntity && (isTrex(e) || isTriceratops(e));
    }

    public static boolean isTamed(MobEntity e) {
        if (e instanceof TameableEntity) return ((TameableEntity) e).isTamed();
        if (e instanceof AbstractHorseEntity) return ((AbstractHorseEntity) e).isTame();
        return false;
    }

    public static UUID getOwnerId(MobEntity e) {
        if (e instanceof TameableEntity) return ((TameableEntity) e).getOwnerId();
        if (e instanceof AbstractHorseEntity) return ((AbstractHorseEntity) e).getOwnerUniqueId();
        return null;
    }

    public static PlayerEntity getOwner(MobEntity e) {
        UUID id = getOwnerId(e);
        return id == null ? null : e.world.getPlayerByUuid(id);
    }

    public static int getMode(MobEntity e) {
        return e.getPersistentData().getInt(MODE_KEY);
    }

    public static void setMode(MobEntity e, int mode) {
        e.getPersistentData().putInt(MODE_KEY, mode);
    }

    public static int nextMode(int mode) {
        return (mode + 1) % 3;
    }

    public static String modeName(int mode) {
        switch (mode) {
            case FOLLOW: return "Following";
            case SIT: return "Sitting";
            default: return "Wandering";
        }
    }

    public static boolean isCommandItem(ItemStack stack) {
        if (stack.isEmpty()) return false;
        ResourceLocation id = ResourceLocation.tryCreate(PFTameConfig.COMMAND_ITEM.get());
        if (id == null) return false;
        Item item = ForgeRegistries.ITEMS.getValue(id);
        return item != null && stack.getItem() == item;
    }

    /** Any meat or fish. */
    public static boolean isMeat(ItemStack stack) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        if (item.isFood()) {
            Food f = item.getFood();
            if (f != null && f.isMeat()) return true;
        }
        ResourceLocation id = item.getRegistryName();
        if (id == null) return false;
        String p = id.getPath();
        return p.contains("meat") || p.contains("steak") || p.contains("flesh")
                || p.contains("beef") || p.contains("pork") || p.contains("mutton")
                || p.contains("chicken") || p.contains("rabbit") || p.contains("drumstick")
                || p.contains("fish") || p.contains("salmon") || p.equals("cod") || p.equals("cooked_cod");
    }
}

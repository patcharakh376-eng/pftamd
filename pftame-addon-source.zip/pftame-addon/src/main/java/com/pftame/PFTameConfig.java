package com.pftame;

import net.minecraftforge.common.ForgeConfigSpec;

public class PFTameConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue TAME_CHANCE;
    public static final ForgeConfigSpec.ConfigValue<String> COMMAND_ITEM;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        TAME_CHANCE = b.comment("Chance (percent) that one piece of meat tames a wild Tyrannosaurus")
                .defineInRange("trexTameChancePercent", 33, 1, 100);
        COMMAND_ITEM = b.comment("Right-click your tamed dinosaur with this item to switch Wander -> Follow -> Sit")
                .define("commandItem", "minecraft:stick");
        SPEC = b.build();
    }
}

package com.pftame;

import java.util.EnumSet;

import net.minecraft.entity.MobEntity;
import net.minecraft.entity.ai.goal.Goal;

/** Blocks all movement while the owner has told the dinosaur to sit. */
public class SitModeGoal extends Goal {
    private final MobEntity mob;

    public SitModeGoal(MobEntity mob) {
        this.mob = mob;
        this.setMutexFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP, Goal.Flag.LOOK));
    }

    @Override
    public boolean shouldExecute() {
        return PetHelper.isTamed(mob) && PetHelper.getMode(mob) == PetHelper.SIT && !mob.isBeingRidden();
    }

    @Override
    public boolean shouldContinueExecuting() {
        return shouldExecute();
    }

    @Override
    public void startExecuting() {
        mob.getNavigator().clearPath();
        mob.setAttackTarget(null);
    }

    @Override
    public void tick() {
        mob.getNavigator().clearPath();
    }
}

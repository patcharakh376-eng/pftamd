package com.pftame;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(PFTame.MODID)
public class PFTame {
    public static final String MODID = "pftame";

    public PFTame() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PFTameConfig.SPEC);
    }
}

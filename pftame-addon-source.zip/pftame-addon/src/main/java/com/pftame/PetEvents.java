package com.pftame;

import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Food;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PFTame.MODID)
public class PetEvents {
    private static final Set<Entity> HOOKED = Collections.newSetFromMap(new WeakHashMap<Entity, Boolean>());

    /** Add our Sit / Follow goals to every Tyrannosaurus and Triceratops. */
    @SubscribeEvent
    public static void onJoin(EntityJoinWorldEvent event) {
        if (event.getWorld().isRemote) return;
        Entity e = event.getEntity();
        if (PetHelper.isManaged(e) && HOOKED.add(e)) {
            MobEntity mob = (MobEntity) e;
            mob.goalSelector.addGoal(0, new SitModeGoal(mob));
            mob.goalSelector.addGoal(3, new FollowModeGoal(mob));
        }
    }

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getWorld().isRemote) return;
        if (event.getHand() != Hand.MAIN_HAND) return;
        Entity target = event.getTarget();
        if (!PetHelper.isManaged(target)) return;

        MobEntity mob = (MobEntity) target;
        PlayerEntity player = event.getPlayer();
        ItemStack stack = player.getHeldItem(Hand.MAIN_HAND);
        boolean trex = PetHelper.isTrex(mob);

        // ---- wild Tyrannosaurus: tame with any meat ----
        if (!PetHelper.isTamed(mob)) {
            if (trex && mob instanceof TameableEntity && PetHelper.isMeat(stack)) {
                if (!player.abilities.isCreativeMode) stack.shrink(1);
                ServerWorld sw = (ServerWorld) mob.world;
                if (mob.getRNG().nextInt(100) < PFTameConfig.TAME_CHANCE.get()) {
                    TameableEntity t = (TameableEntity) mob;
                    t.setTamed(true);
                    t.setOwnerId(player.getUniqueID());
                    mob.enablePersistence();
                    mob.getNavigator().clearPath();
                    mob.setAttackTarget(null);
                    PetHelper.setMode(mob, PetHelper.WANDER);
                    sw.spawnParticle(ParticleTypes.HEART, mob.getPosX(), mob.getPosY() + mob.getHeight() * 0.8D, mob.getPosZ(), 10, 0.6D, 0.6D, 0.6D, 0.02D);
                    player.sendStatusMessage(new StringTextComponent("Tyrannosaurus tamed!"), true);
                } else {
                    sw.spawnParticle(ParticleTypes.SMOKE, mob.getPosX(), mob.getPosY() + mob.getHeight() * 0.8D, mob.getPosZ(), 10, 0.6D, 0.6D, 0.6D, 0.02D);
                }
                consume(event);
            }
            return;
        }

        // ---- tamed: owner only ----
        UUID owner = PetHelper.getOwnerId(mob);
        if (owner == null || !owner.equals(player.getUniqueID())) return;

        if (PetHelper.isCommandItem(stack)) {
            int next = PetHelper.nextMode(PetHelper.getMode(mob));
            PetHelper.setMode(mob, next);
            mob.getNavigator().clearPath();
            if (next == PetHelper.SIT) mob.setAttackTarget(null);
            player.sendStatusMessage(new StringTextComponent(PetHelper.modeName(next)), true);
            consume(event);
        } else if (trex && PetHelper.isMeat(stack) && mob.getHealth() < mob.getMaxHealth()) {
            Food f = stack.getItem().getFood();
            float heal = Math.max(4.0F, (f == null ? 2 : f.getHealing()) * 5.0F);
            mob.heal(heal);
            if (!player.abilities.isCreativeMode) stack.shrink(1);
            ServerWorld sw = (ServerWorld) mob.world;
            sw.spawnParticle(ParticleTypes.HEART, mob.getPosX(), mob.getPosY() + mob.getHeight() * 0.8D, mob.getPosZ(), 5, 0.6D, 0.6D, 0.6D, 0.02D);
            consume(event);
        }
    }

    private static void consume(PlayerInteractEvent.EntityInteract event) {
        event.setCanceled(true);
        event.setCancellationResult(ActionResultType.SUCCESS);
    }

    /** Tamed dinosaurs never target their owner, and stand still while sitting. */
    @SubscribeEvent
    public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        LivingEntity le = event.getEntityLiving();
        if (le.world.isRemote || !PetHelper.isManaged(le)) return;
        MobEntity mob = (MobEntity) le;
        if (!PetHelper.isTamed(mob)) return;

        UUID owner = PetHelper.getOwnerId(mob);
        LivingEntity target = mob.getAttackTarget();
        if (target != null && owner != null && owner.equals(target.getUniqueID())) {
            mob.setAttackTarget(null);
        }
        if (PetHelper.getMode(mob) == PetHelper.SIT && !mob.isBeingRidden()) {
            mob.setAttackTarget(null);
            Vector3d m = mob.getMotion();
            mob.setMotion(0.0D, m.y, 0.0D);
        }
    }

    /** Safety net: block any damage a tamed dinosaur would deal to its owner. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        Entity src = event.getSource().getTrueSource();
        if (src == null || !PetHelper.isManaged(src)) return;
        MobEntity pet = (MobEntity) src;
        if (!PetHelper.isTamed(pet)) return;
        UUID owner = PetHelper.getOwnerId(pet);
        if (owner != null && owner.equals(event.getEntityLiving().getUniqueID())) {
            event.setCanceled(true);
        }
    }
}

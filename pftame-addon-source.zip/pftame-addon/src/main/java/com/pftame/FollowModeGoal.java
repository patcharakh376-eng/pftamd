package com.pftame;

import java.util.EnumSet;

import net.minecraft.entity.MobEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;

/** Walks toward the owner while in Follow mode. */
public class FollowModeGoal extends Goal {
    private static final double START_DIST = 6.0D;
    private static final double STOP_DIST = 3.5D;
    private static final double TELEPORT_DIST = 28.0D;

    private final MobEntity mob;
    private PlayerEntity owner;
    private int recalc;

    public FollowModeGoal(MobEntity mob) {
        this.mob = mob;
        this.setMutexFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean shouldExecute() {
        if (!PetHelper.isTamed(mob) || PetHelper.getMode(mob) != PetHelper.FOLLOW || mob.isBeingRidden()) return false;
        PlayerEntity p = PetHelper.getOwner(mob);
        if (p == null || p.isSpectator()) return false;
        this.owner = p;
        return mob.getDistanceSq(p) > START_DIST * START_DIST;
    }

    @Override
    public boolean shouldContinueExecuting() {
        return owner != null && owner.isAlive()
                && PetHelper.isTamed(mob) && PetHelper.getMode(mob) == PetHelper.FOLLOW
                && !mob.isBeingRidden()
                && mob.getDistanceSq(owner) > STOP_DIST * STOP_DIST;
    }

    @Override
    public void startExecuting() {
        recalc = 0;
    }

    @Override
    public void resetTask() {
        owner = null;
        mob.getNavigator().clearPath();
    }

    @Override
    public void tick() {
        mob.getLookController().setLookPositionWithEntity(owner, 10.0F, (float) mob.getVerticalFaceSpeed());
        if (--recalc <= 0) {
            recalc = 10;
            if (mob.getDistanceSq(owner) > TELEPORT_DIST * TELEPORT_DIST) {
                tryTeleport();
            } else {
                mob.getNavigator().tryMoveToEntityLiving(owner, 1.2D);
            }
        }
    }

    private void tryTeleport() {
        for (int i = 0; i < 12; i++) {
            int dx = (mob.getRNG().nextBoolean() ? 1 : -1) * (2 + mob.getRNG().nextInt(3));
            int dz = (mob.getRNG().nextBoolean() ? 1 : -1) * (2 + mob.getRNG().nextInt(3));
            if (mob.attemptTeleport(owner.getPosX() + dx, owner.getPosY(), owner.getPosZ() + dz, false)) {
                mob.getNavigator().clearPath();
                return;
            }
        }
    }
}
